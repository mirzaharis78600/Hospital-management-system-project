package com.mycompany.project11;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Project11 {
    public static void main(String[] args) throws SQLException {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String connectURL = "jdbc:sqlserver://localhost:1433;databaseName=Hospital;user=sa;password=mirza;encrypt=false";

        Connection conn = DriverManager.getConnection(connectURL);
            System.out.println("Connecting to the database successfully");

            String sql = "INSERT INTO dbo.Hospital1 (name, contact) VALUES (?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            String name = "HDK";
            String contact = "02222";
                
            pstmt.setString(1, name);
            pstmt.setString(2, contact);
            pstmt.executeUpdate();

            System.out.println("Data inserted successfully");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Project11.class.getName()).log(Level.SEVERE, null, ex);
        }
        
}

    public static void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
